package filing;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class filing {

    // Non_Fiction Books
    public static void Educated() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Educated.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void In_Cold_Blood() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\In Cold Blood.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void Into_Thin_Air() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Into Thin Air.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }


    public static void Silent_Spring() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Silent Spring.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    // fiction books
    public static void Elements_of_Friction_Theory_and_Nanotribology() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Elements of Friction Theory and Nanotribology.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void Experiments_with_Friction() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Experiments with Friction.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void Focus_on_Friction() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Focus on Friction.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void What_is_Friction() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\What Is Friction.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    // Thriller

    public static void Gone_Girl() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Gone Girl.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void The_Girl_on_the_Train() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The Girl on the Train.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void The_Silent_Patient() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The Silent Patient.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void Verity() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\Verity.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    // DVD

    public static void The_Biographers_Tale() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The Biographer's Tale.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void The_Dancing_Floor() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The Dancing Floor.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void The_New_Testament() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The New Testament.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    public static void The_Pearl_Driver() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\Books\\The Pearl Diver.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();
    }

    // Welcome message
    public static void Welcome_message() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\filing\\other files\\Welcome message.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();

    }

    // display books available in Fiction category
    public static void Fiction_books() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\filing\\other files\\Fiction Books.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();

    }

    public static void Thirller_books() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\filing\\other files\\Thirller Books.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();

    }

    public static void Non_fiction_books() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\filing\\other files\\Non Fiction books.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();

    }

    public static void DVDs() throws IOException {
        FileReader f1 = new FileReader("D:\\OOP(JAVA)\\Project_Sem2\\filing\\other files\\DVDS.txt");
        int data;
        while ((data = f1.read()) != -1) {
            System.out.print((char) data);
        }
        System.out.println("");
        f1.close();

    }


}



