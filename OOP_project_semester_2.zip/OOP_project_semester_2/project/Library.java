import java.util.Scanner;

public class Library {

    public void addBook(Scanner scanner) {
    }

    public void removeBook(Scanner scanner) {
    }

}
